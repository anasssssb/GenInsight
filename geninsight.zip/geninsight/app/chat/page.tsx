import { MainNav } from "@/components/main-nav"
import { UserNav } from "@/components/user-nav"
import { Search } from "@/components/search"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"

export default function ChatPage() {
  return (
    <div className="flex-col md:flex">
      <div className="border-b">
        <div className="flex h-16 items-center px-4">
          <MainNav className="mx-6" />
          <div className="ml-auto flex items-center space-x-4">
            <Search />
            <UserNav />
          </div>
        </div>
      </div>
      <div className="flex-1 space-y-4 p-8 pt-6">
        <div className="flex items-center justify-between space-y-2">
          <h2 className="text-3xl font-bold tracking-tight">Chat Assistant</h2>
        </div>
        <Card className="flex flex-col h-[calc(100vh-200px)]">
          <CardHeader>
            <CardTitle>Chat with GenInsight AI</CardTitle>
          </CardHeader>
          <CardContent className="flex-1 flex flex-col">
            <ScrollArea className="flex-1 pr-4">
              <div className="space-y-4">
                <div className="flex flex-col space-y-2">
                  <div className="bg-secondary p-3 rounded-lg inline-block">
                    Hello! How can I assist you today?
                  </div>
                  <div className="bg-primary text-primary-foreground p-3 rounded-lg inline-block self-end">
                    Can you help me analyze my sales data?
                  </div>
                  <div className="bg-secondary p-3 rounded-lg inline-block">
                    I'd be happy to help you analyze your sales data. Could you please provide more information about what specific aspects of your sales data you'd like to analyze? For example, are you interested in trends over time, top-selling products, customer segmentation, or something else?
                  </div>
                </div>
              </div>
            </ScrollArea>
            <div className="flex items-center space-x-2 mt-4">
              <Input placeholder="Type your message here..." />
              <Button>Send</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

