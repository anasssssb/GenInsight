import { MainNav } from "@/components/main-nav"
import { UserNav } from "@/components/user-nav"
import { Search } from "@/components/search"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function AutoMLPage() {
  return (
    <div className="flex-col md:flex">
      <div className="border-b">
        <div className="flex h-16 items-center px-4">
          <MainNav className="mx-6" />
          <div className="ml-auto flex items-center space-x-4">
            <Search />
            <UserNav />
          </div>
        </div>
      </div>
      <div className="flex-1 space-y-4 p-8 pt-6">
        <div className="flex items-center justify-between space-y-2">
          <h2 className="text-3xl font-bold tracking-tight">AutoML</h2>
        </div>
        <Tabs defaultValue="setup" className="space-y-4">
          <TabsList>
            <TabsTrigger value="setup">Setup</TabsTrigger>
            <TabsTrigger value="training">Training</TabsTrigger>
            <TabsTrigger value="results">Results</TabsTrigger>
          </TabsList>
          <TabsContent value="setup" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Dataset Selection</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="space-y-1">
                  <Label htmlFor="dataset">Select Dataset</Label>
                  <Select>
                    <SelectTrigger id="dataset">
                      <SelectValue placeholder="Select a dataset" />
                    </SelectTrigger>
                    <SelectContent position="popper">
                      <SelectItem value="sales_data">Sales Data</SelectItem>
                      <SelectItem value="customer_data">Customer Data</SelectItem>
                      <SelectItem value="product_data">Product Data</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label htmlFor="target">Target Variable</Label>
                  <Select>
                    <SelectTrigger id="target">
                      <SelectValue placeholder="Select target variable" />
                    </SelectTrigger>
                    <SelectContent position="popper">
                      <SelectItem value="sales">Sales</SelectItem>
                      <SelectItem value="customer_satisfaction">Customer Satisfaction</SelectItem>
                      <SelectItem value="product_rating">Product Rating</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button>Next</Button>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="training" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Model Training</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="space-y-1">
                  <Label htmlFor="model-type">Model Type</Label>
                  <Select>
                    <SelectTrigger id="model-type">
                      <SelectValue placeholder="Select model type" />
                    </SelectTrigger>
                    <SelectContent position="popper">
                      <SelectItem value="regression">Regression</SelectItem>
                      <SelectItem value="classification">Classification</SelectItem>
                      <SelectItem value="clustering">Clustering</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label htmlFor="training-time">Training Time (minutes)</Label>
                  <Input id="training-time" type="number" defaultValue="30" />
                </div>
                <Button>Start Training</Button>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="results" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Model Results</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Model training complete. Here are the results:</p>
                <ul className="list-disc pl-4 mt-2 space-y-1">
                  <li>Best Model: Random Forest</li>
                  <li>Accuracy: 0.92</li>
                  <li>F1 Score: 0.91</li>
                  <li>Training Time: 25 minutes</li>
                </ul>
                <Button className="mt-4">Download Model</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

