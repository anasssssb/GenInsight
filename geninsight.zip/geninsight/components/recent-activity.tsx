import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export function RecentActivity() {
  return (
    <Card className="col-span-4">
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
        <CardDescription>
          You made 265 sales this month.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-8">
          <div className="flex items-center">
            <div className="ml-4 space-y-1">
              <p className="text-sm font-medium leading-none">Data analysis completed</p>
              <p className="text-sm text-muted-foreground">
                Sales report for Q3 2023
              </p>
            </div>
            <div className="ml-auto font-medium">Just now</div>
          </div>
          <div className="flex items-center">
            <div className="ml-4 space-y-1">
              <p className="text-sm font-medium leading-none">New team member added</p>
              <p className="text-sm text-muted-foreground">
                John Doe joined the Analytics team
              </p>
            </div>
            <div className="ml-auto font-medium">2 hours ago</div>
          </div>
          <div className="flex items-center">
            <div className="ml-4 space-y-1">
              <p className="text-sm font-medium leading-none">Dashboard updated</p>
              <p className="text-sm text-muted-foreground">
                New visualizations added to Sales dashboard
              </p>
            </div>
            <div className="ml-auto font-medium">5 hours ago</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

